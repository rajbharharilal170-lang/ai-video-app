import uvicorn
import os
import sys

def main():
    # Add the backend directory to the Python path
    backend_path = os.path.join(os.path.dirname(__file__), "backend")
    sys.path.insert(0, backend_path)
    
    # Change to the backend directory
    os.chdir(backend_path)
    
    # Import the app after setting up paths
    from main import app
    
    # Run the FastAPI application
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)

if __name__ == "__main__":
    main()