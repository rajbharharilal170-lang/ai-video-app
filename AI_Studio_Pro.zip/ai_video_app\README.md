# AI Video Studio Pro

A professional AI-powered video processing application with advanced features.

## Features

1. **Video Upload & Processing**
   - Upload videos with optional effects (cartoon, watermark)
   - Quality conversion (SD, HD, FHD, UHD)

2. **Text-to-Video Generation**
   - Convert text prompts to videos
   - Multiple styles (realistic, cartoon, anime, abstract)
   - Customizable duration

3. **AI Avatar Creation**
   - Create avatar videos from scripts
   - Custom avatar images
   - Voice selection

4. **Job Management**
   - Track processing status
   - View job history
   - Download processed videos

## Installation

1. Install required packages:
   ```
   pip install -r requirements.txt
   ```

2. Run the application:
   ```
   python run.py
   ```

3. Open your browser and go to:
   ```
   http://127.0.0.1:8000
   ```

## API Documentation

- Swagger UI: http://127.0.0.1:8000/api/docs
- ReDoc: http://127.0.0.1:8000/api/redoc

## Usage

1. **Upload Video**: Select a video file and apply optional effects
2. **Text-to-Video**: Enter a text prompt to generate a video
3. **AI Avatar**: Create an avatar video with a script and optional image
4. **Job Status**: Check the status of your processing jobs
5. **Download**: Download processed videos in various qualities

## Directory Structure

```
ai_video_app/
├── backend/
│   ├── main.py          # FastAPI application
│   ├── output/          # Processed videos
│   └── jobs.json        # Job storage
├── frontend/
│   └── index.html       # Web interface
├── run.py               # Application runner
└── requirements.txt     # Python dependencies
```