from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uuid, os, shutil, json, time
from pathlib import Path
from typing import Optional
from datetime import datetime
import asyncio

app = FastAPI(
    title="AI Video Studio Pro API", 
    description="Professional AI Video Processing API with Advanced Features", 
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE = os.path.dirname(__file__)
OUTPUT = os.path.join(BASE, "output")
JOBS = os.path.join(BASE, "jobs.json")
FRONT = os.path.join(BASE, "static")

os.makedirs(OUTPUT, exist_ok=True)
os.makedirs(FRONT, exist_ok=True)

# Allowed file extensions
ALLOWED_VIDEO_EXTENSIONS = {'.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv'}
ALLOWED_IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB

# Copy frontend into static at startup (served)
if __name__ != "__main__":
    try:
        frontend_index = os.path.join(BASE, "..", "frontend", "index.html")
        if os.path.exists(frontend_index):
            shutil.copyfile(frontend_index, os.path.join(FRONT, "index.html"))
    except Exception as e:
        print(f"Warning: Could not copy frontend file: {e}")

# Simple jobs storage
if not os.path.exists(JOBS):
    with open(JOBS, "w") as f:
        json.dump({}, f)

def save_job(jid, data):
    try:
        with open(JOBS, "r+") as f:
            obj = json.load(f)
            obj[jid] = data
            f.seek(0)
            f.truncate()
            json.dump(obj, f, indent=2)
    except Exception as e:
        print(f"Error saving job: {e}")

def get_job(jid):
    try:
        with open(JOBS, "r") as f:
            obj = json.load(f)
        return obj.get(jid)
    except Exception as e:
        print(f"Error loading job: {e}")
        return None

def validate_file(file: UploadFile, allowed_extensions: set, max_size: int = MAX_FILE_SIZE):
    """Validate uploaded file"""
    # Check file extension
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid file type. Allowed types: {', '.join(allowed_extensions)}"
        )
    return True

async def save_uploaded_file(file: UploadFile, output_path: str):
    """Save uploaded file with size validation"""
    try:
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File size exceeds maximum allowed size of {MAX_FILE_SIZE / (1024*1024)}MB"
            )
        with open(output_path, "wb") as out:
            out.write(content)
        return content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")

def create_sample_video(video_path, content="Sample Video Content"):
    """Create a minimal valid MP4 video file"""
    import struct
    
    # Create a minimal valid MP4 file structure
    with open(video_path, "wb") as f:
        # ftyp box (file type)
        ftyp = b'\x00\x00\x00\x20ftyp'
        ftyp += b'mp42\x00\x00\x00\x00mp42isom'
        f.write(ftyp)
        
        # free box (padding)
        free = b'\x00\x00\x00\x08free'
        f.write(free)
        
        # mdat box (media data) - contains actual video data
        video_data = b'\x00' * 1024  # 1KB of video data
        mdat_size = struct.pack('>I', len(video_data) + 8)
        f.write(mdat_size + b'mdat' + video_data)
        
        # moov box (movie metadata)
        moov_data = b'\x00\x00\x00\x6cmoov'
        moov_data += b'\x00\x00\x00\x64mvhd'
        moov_data += b'\x00\x00\x00\x00'  # version/flags
        moov_data += b'\x00\x00\x00\x00'  # creation time
        moov_data += b'\x00\x00\x00\x00'  # modification time
        moov_data += b'\x00\x00\x03\xe8'  # timescale (1000)
        moov_data += b'\x00\x00\x00\x0a'  # duration (10)
        moov_data += b'\x00\x01\x00\x00'  # rate
        moov_data += b'\x01\x00'  # volume
        moov_data += b'\x00\x00'  # reserved
        moov_data += b'\x00\x00\x00\x00\x00\x00\x00\x00'  # reserved
        moov_data += b'\x00\x01\x00\x00' + b'\x00' * 12
        moov_data += b'\x00\x01\x00\x00' + b'\x00' * 12
        moov_data += b'\x40\x00\x00\x00'  # matrix
        moov_data += b'\x00' * 24  # pre-defined
        moov_data += b'\x00\x00\x00\x01'  # next track ID
        f.write(moov_data)

def create_sample_image(image_path, content="Sample Image Content"):
    """Create a simple image-like file with basic structure"""
    # Create a simple file that resembles a PNG image file
    with open(image_path, "wb") as f:
        # Write PNG signature
        f.write(b"\x89PNG\r\n\x1a\n")
        # Write IHDR chunk (image header)
        f.write(b"\x00\x00\x00\x0dIHDR")
        # Image dimensions (100x100)
        f.write(b"\x00\x00\x00\x64\x00\x00\x00\x64")
        # Bit depth and color type
        f.write(b"\x08\x02\x00\x00\x00")
        # Add some content
        content_bytes = content.encode('utf-8', errors='ignore')
        f.write(content_bytes * 50)
        # Add some binary data to make it look more like a real image file
        f.write(b"\x00" * 2000)
        # Add random data to simulate image data
        import random
        f.write(bytes([random.randint(0, 255) for _ in range(5000)]))
        # Write IEND chunk
        f.write(b"\x00\x00\x00\x00IEND\xaeB`\x82")

def create_quality_versions(base_video_path, job_id):
    """Create different quality versions of a video"""
    # In a real implementation, this would use ffmpeg or similar to create different quality versions
    # For this demo, we'll just create symbolic names for different qualities
    
    qualities = {
        "sd": f"{job_id}_sd.mp4",     # 480p
        "hd": f"{job_id}_hd.mp4",     # 720p
        "fhd": f"{job_id}_fhd.mp4",   # 1080p
        "uhd": f"{job_id}_uhd.mp4"    # 4K
    }
    
    # For demo purposes, we'll copy the base video to all quality versions
    for quality_file in qualities.values():
        quality_path = os.path.join(OUTPUT, quality_file)
        if not os.path.exists(quality_path):
            shutil.copyfile(base_video_path, quality_path)
    
    return qualities

def compress_video_file(input_path, output_path, compression_level="medium"):
    """Simulate video compression"""
    # In a real implementation, this would use ffmpeg to compress the video
    # For this demo, we'll just copy the file and adjust the size based on compression level
    shutil.copyfile(input_path, output_path)
    
    # Simulate compression by reducing file size (in a real app, this would be actual compression)
    compression_factors = {
        "low": 0.9,    # 10% reduction
        "medium": 0.7, # 30% reduction
        "high": 0.5    # 50% reduction
    }
    
    # Just return the compression factor for demo purposes
    return compression_factors.get(compression_level, 0.7)

@app.post("/api/upload", summary="Upload and Process Video")
async def api_upload(
    file: UploadFile = File(...), 
    cartoon: str = Form("off"),
    watermark: str = Form("off")
):
    """Upload a video file for processing with optional effects"""
    try:
        # Validate file
        validate_file(file, ALLOWED_VIDEO_EXTENSIONS)
        
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        
        # Save file with validation
        content = await save_uploaded_file(file, saved)
        
        # Simulate processing: create a sample video as result
        result_name = f"{jid}.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Create a sample video file
        create_sample_video(result_path, f"Processed video from {file.filename}")
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "upload",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "size": len(content),
                "qualities": quality_versions,
                "effects": {
                    "cartoon": cartoon == "on",
                    "watermark": watermark == "on"
                }
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": "Video uploaded and processed successfully",
            "estimated_processing_time": "instant"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")

@app.post("/api/text2video", summary="Generate Video from Text")
async def api_text2video(
    prompt: str = Form(...), 
    style: str = Form("realistic"),
    duration: int = Form(10)
):
    """Generate a video from text prompt with style and duration options"""
    try:
        jid = str(uuid.uuid4())[:12]
        result_name = f"{jid}.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate AI processing: create a sample video based on the prompt
        # Create larger video file based on duration
        video_content = f"AI-generated video based on prompt: {prompt} (Style: {style}, Duration: {duration}s)"
        create_sample_video(result_path, video_content)
        
        # For longer videos, create a larger file
        if duration > 60:
            # Append more data for longer videos
            with open(result_path, "ab") as f:
                import random
                # Add more random data based on duration
                extra_size = int(duration * 500)  # Approximately 500 bytes per second
                f.write(bytes([random.randint(0, 255) for _ in range(extra_size)]))
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "text2video",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "prompt": prompt,
                "style": style,
                "duration": duration,
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": f"Video generated successfully from text ({duration} seconds)",
            "estimated_processing_time": "instant"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation error: {str(e)}")

@app.post("/api/avatar", summary="Create AI Avatar Video")
async def api_avatar(
    script: str = Form(...), 
    image: UploadFile = File(None),
    voice: str = Form("default")
):
    """Create an AI avatar video from script with optional image and voice settings"""
    try:
        jid = str(uuid.uuid4())[:12]
        result_name = f"{jid}.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Handle optional image upload
        image_filename = None
        if image:
            image_filename = f"{jid}_avatar.jpg"
            image_path = os.path.join(OUTPUT, image_filename)
            with open(image_path, "wb") as out:
                out.write(await image.read())
        
        # Simulate AI processing: create a sample avatar video
        create_sample_video(result_path, f"AI avatar video based on script: {script} (Voice: {voice})")
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "avatar",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "script": script,
                "avatar_image": image_filename,
                "voice": voice,
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": "AI avatar video created successfully",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Avatar creation error: {str(e)}")

@app.post("/api/compress", summary="Compress Video")
async def api_compress(
    file: UploadFile = File(...),
    compression_level: str = Form("medium")
):
    """Compress a video file with specified compression level"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        with open(saved, "wb") as out:
            content = await file.read()
            out.write(content)
        
        # Compress the video
        result_name = f"{jid}_compressed.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate compression
        compression_factor = compress_video_file(saved, result_path, compression_level)
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "compress",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "compression_level": compression_level,
                "size_reduction": f"{int((1-compression_factor)*100)}%",
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": "Video compressed successfully",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Compression error: {str(e)}")

@app.post("/api/convert", summary="Convert Video Format")
async def api_convert(
    file: UploadFile = File(...),
    target_format: str = Form("mp4")
):
    """Convert a video file to a different format"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        with open(saved, "wb") as out:
            content = await file.read()
            out.write(content)
        
        # Convert the video
        result_name = f"{jid}.{target_format}"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate conversion
        convert_video_format(saved, result_path, target_format)
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "convert",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "target_format": target_format,
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": f"Video converted to {target_format} format successfully",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Conversion error: {str(e)}")

@app.post("/api/merge", summary="Merge Multiple Videos")
async def api_merge(
    files: list[UploadFile] = File(...)
):
    """Merge multiple video files into one"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved_files = []
        
        # Save all uploaded files
        for i, file in enumerate(files):
            saved = os.path.join(OUTPUT, f"{jid}_{i}.uploaded")
            with open(saved, "wb") as out:
                content = await file.read()
                out.write(content)
            saved_files.append(saved)
        
        # Merge the videos
        result_name = f"{jid}_merged.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate merging
        merge_video_files(saved_files, result_path)
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "merge",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "merged_files_count": len(files),
                "merged_files_names": [file.filename for file in files],
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": f"Successfully merged {len(files)} videos",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Merge error: {str(e)}")

@app.get("/api/status/{job_id}", summary="Check Job Status")
async def api_status(job_id: str):
    """Check the status of a video processing job with full details"""
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.get("/api/jobs", summary="List All Jobs")
async def list_jobs(limit: int = 10):
    """List all video processing jobs"""
    try:
        with open(JOBS, "r") as f:
            obj = json.load(f)
        # Return last N jobs
        jobs = list(obj.items())[-limit:] if len(obj) > limit else list(obj.items())
        return {"jobs": dict(jobs), "total": len(obj)}
    except Exception as e:
        return {"jobs": {}, "total": 0, "error": str(e)}

@app.get("/download/{filename}", summary="Download Processed Video")
async def download_file(
    filename: str, 
    quality: Optional[str] = Query("original", description="Video quality: original, sd, hd, fhd, uhd (4K)"),
    format: Optional[str] = Query("mp4", description="Video format: mp4, avi, mov")
):
    """Download a processed video file with specified quality and format"""
    # Security check: ensure filename doesn't contain path traversal
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(status_code=400, detail="Invalid filename")
    
    # Handle quality versions
    if quality != "original":
        # Replace extension with quality tag
        name_part, ext = os.path.splitext(filename)
        if quality in ["sd", "hd", "fhd", "uhd"]:
            filename = f"{name_part}_{quality}{ext}"
    
    path = os.path.join(OUTPUT, filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="File not found")
    
    # Determine media type based on file extension
    if filename.endswith(".mp4"):
        media_type = "video/mp4"
    elif filename.endswith(".avi"):
        media_type = "video/avi"
    elif filename.endswith(".mov"):
        media_type = "video/quicktime"
    elif filename.endswith(".jpg") or filename.endswith(".jpeg"):
        media_type = "image/jpeg"
    elif filename.endswith(".png"):
        media_type = "image/png"
    else:
        media_type = "application/octet-stream"
    
    return FileResponse(
        path, 
        media_type=media_type, 
        filename=filename
    )

# Serve frontend
app.mount("/", StaticFiles(directory=FRONT, html=True), name="static")

def convert_video_format(input_path, output_path, target_format):
    """Simulate video format conversion"""
    # In a real implementation, this would use ffmpeg to convert formats
    # For this demo, we'll just copy the file and change extension
    shutil.copyfile(input_path, output_path)
    return output_path

def merge_video_files(video_paths, output_path):
    """Simulate merging multiple video files"""
    # In a real implementation, this would use ffmpeg to concatenate videos
    # For this demo, we'll create a sample video with information about merged files
    merged_info = "Merged videos: " + ", ".join([os.path.basename(path) for path in video_paths])
    create_sample_video(output_path, merged_info)
    return output_path

def merge_images(image_paths, output_path):
    """Simulate merging multiple images"""
    # In a real implementation, this would use PIL or similar to combine images
    # For this demo, we'll create a sample image with information about merged files
    merged_info = "Merged images: " + ", ".join([os.path.basename(path) for path in image_paths])
    create_sample_image(output_path, merged_info)
    return output_path

def convert_image_format(input_path, output_path, target_format):
    """Simulate image format conversion"""
    # In a real implementation, this would use PIL to convert formats
    # For this demo, we'll just copy the file and change extension
    shutil.copyfile(input_path, output_path)
    return output_path

def add_watermark_to_video(input_path, output_path, watermark_text):
    """Simulate adding watermark to video"""
    # In a real implementation, this would use ffmpeg to add watermarks
    # For this demo, we'll create a sample video with watermark info
    watermark_info = f"Video with watermark: {watermark_text}"
    create_sample_video(output_path, watermark_info)
    return output_path

@app.post("/api/watermark", summary="Add Watermark to Video")
async def api_watermark(
    file: UploadFile = File(...),
    watermark_text: str = Form("AI Video Studio Pro")
):
    """Add a text watermark to a video file"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        with open(saved, "wb") as out:
            content = await file.read()
            out.write(content)
        
        # Add watermark to the video
        result_name = f"{jid}_watermarked.mp4"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate watermarking
        add_watermark_to_video(saved, result_path, watermark_text)
        
        # Create different quality versions
        quality_versions = create_quality_versions(result_path, jid)
        
        job = {
            "status": "done",
            "type": "watermark",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "watermark_text": watermark_text,
                "qualities": quality_versions
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": "Watermark added to video successfully",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Watermark error: {str(e)}")

@app.post("/api/upload_image", summary="Upload and Process Image")
async def api_upload_image(
    file: UploadFile = File(...), 
    effect: str = Form("none")
):
    """Upload an image file for processing with optional effects"""
    try:
        # Validate file
        validate_file(file, ALLOWED_IMAGE_EXTENSIONS)
        
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        
        # Save file with validation
        content = await save_uploaded_file(file, saved)
        
        # Process the image
        result_name = f"{jid}.png"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Create a sample image file
        create_sample_image(result_path, f"Processed image from {file.filename} with {effect} effect")
        
        job = {
            "status": "done",
            "type": "upload_image",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "effect": effect
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": "Image uploaded and processed successfully",
            "estimated_processing_time": "instant"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing error: {str(e)}")

@app.post("/api/merge_images", summary="Merge Multiple Images")
async def api_merge_images(
    files: list[UploadFile] = File(...)
):
    """Merge multiple image files into one collage"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved_files = []
        
        # Save all uploaded files
        for i, file in enumerate(files):
            saved = os.path.join(OUTPUT, f"{jid}_{i}.uploaded")
            with open(saved, "wb") as out:
                content = await file.read()
                out.write(content)
            saved_files.append(saved)
        
        # Merge the images
        result_name = f"{jid}_merged.png"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate merging
        merge_images(saved_files, result_path)
        
        job = {
            "status": "done",
            "type": "merge_images",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "merged_files_count": len(files),
                "merged_files_names": [file.filename for file in files]
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": f"Successfully merged {len(files)} images",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Merge error: {str(e)}")

@app.post("/api/convert_image", summary="Convert Image Format")
async def api_convert_image(
    file: UploadFile = File(...),
    target_format: str = Form("png")
):
    """Convert an image file to a different format"""
    try:
        jid = str(uuid.uuid4())[:12]
        saved = os.path.join(OUTPUT, f"{jid}.uploaded")
        with open(saved, "wb") as out:
            content = await file.read()
            out.write(content)
        
        # Convert the image
        result_name = f"{jid}.{target_format}"
        result_path = os.path.join(OUTPUT, result_name)
        
        # Simulate conversion
        convert_image_format(saved, result_path, target_format)
        
        job = {
            "status": "done",
            "type": "convert_image",
            "progress": 100,
            "created": datetime.now().isoformat(),
            "result": {
                "file": result_name,
                "original_filename": file.filename,
                "target_format": target_format
            }
        }
        save_job(jid, job)
        return {
            "job_id": jid, 
            "status": "created", 
            "message": f"Image converted to {target_format} format successfully",
            "estimated_processing_time": "instant"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Conversion error: {str(e)}")
